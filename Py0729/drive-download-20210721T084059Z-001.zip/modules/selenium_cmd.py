try:
    from selenium.webdriver import Chrome, ChromeOptions
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.common.by import By
except ModuleNotError as e:
    print('Module Not Found, Please Install > "pip install selenium" .')

desc='''

What is 'Selenium' ?
    - https://www.selenium.dev/documentation/ja/introduction/the_selenium_project_and_tools/
    - SeleniumはWebブラウザーを制御します。
    - 今回はChromeを使用しています。
    - 
    - https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/
'''

class WebAppHeadlessCmd:

    AppName='Web Application (Auto|AI) Test Command by Selenium'
    Description="""
    - First Program
    app=WebAppHeadlessCmd(option=['--headless', '', ''])
    app.command('Dos')
    app.close()
        - or -
    app.quit()
    """

    def __init__(self, option=['--headless']):
        self.options = ChromeOptions()
        if len(option)>0:
            for o in range(0, len(option)):
                self.options.add_argument(option[o])
        self.driver = Chrome(options=self.options)
    
    def close(self):
        self.driver.close()
    
    def quit(self):
        self.driver.quit()

    def get(self,url):
        self.driver.get(url)
    
    def setUrl(self,url):
        self.url=url
    def getUrl(self):
        return self.url
    
    def DDos(self):
        # 対象のウェブサイトやサーバーに対して複数のコンピューターから大量に行うこと
        pass

    def Dos(self, num=10):
        # 大量のデータや不正なデータを送り付けること
        self.get(self.getUrl())
        count=0
        while True:
            count+=1
            if count<num:
                self.driver.refresh()
    
    def SqlInjection(self):
        Injection=[
            """
            SELECT * FROM users WHERE name = 't' OR 't' = 't';
            """
            ,
            """
            SELECT * FROM users WHERE name = '\'' OR 1=1 --';
            """
        ]
        pass
    
    def Xss(self):
        # 攻撃対象のWebサイトの脆弱性を突き、攻撃者がそこに悪質なサイトへ誘導するスクリプトを仕掛けることで、
        # サイトに訪れるユーザーの個人情報などを詐取する攻撃のことを指します。
        XssScript=[
            """
                while(true){
                    window.location.href='/'
                }
            """
        ]
        pass

    def DirectoryTraversal(self):
        # ファイル名を扱うようなプログラムに対して特殊な文字列を送信することにより、
        # 通常はアクセスできないファイルやディレクトリ（フォルダ）の内容を取得する手法。
        Dt='cd ../|cat /etc/passwd'
        pass

    def BootstrapForm(self):
        pass
    
    def getScript(self, javascript):
        return javascript
    
    def setScript(self, javascript):
        self.javascript=javascript

    def HtmlSelector(self, selector='body'):
        # Initialize Tag='<body> Tag's'
        header=driver.find_element(By.CSS_SELECTOR, selector)
        self.driver.execute_script(self.javascript, header)

    # 耐久系
    def AutoInsert(self):
        sql=f'INSERT INTO XXX VALUES(?,?,?,?);'


    def AutoSelect(self):
        sql=f'SELECT * FROM {tbl};'

    def AutoUpdate(self):
        pass

    def AutoDelete(self):
        pass


# Test:=
"""
url='http://localhost/'
w=WebAppHeadlessCmd()
w.setUrl(url)
w.Dos()
"""

"""
options=ChromeOptions()

driver=Chrome(options=options)
driver.get('http://localhost:50000/')
header=driver.find_element(By.CSS_SELECTOR, "body")
"""

javascript='''

/* Inspect Selector: Body, */
// document.body.innerHTML='こんにちは！！'
/* コメントアウトしています。 */
/*  */
'''
driver.execute_script(javascript, header)





