import os, sys, datetime,sqlite3
from flask import Flask, render_template, request, redirect
from modules import *

############################################################
############################################################
# FrameWorks
# 
############################################################
# 
############################################################
port=50000
debug=True

db_name='./database/ledger.db'

app=Flask(__name__)

@app.route('/')
def index():
    items=[]
    conn=sqlite3.connect(db_name)
    cursor=conn.cursor()
    sql='SELECT * from COMPANY_DOCUMENT_LIST;'
    cursor.execute(sql)
    items=cursor.fetchall()
    conn.close()
    # print(items)
    return render_template(
    'main.html',
    items=items)

@app.route('/create', methods=["POST"])
def create():
    return 'CREATE TEST'

@app.route('/insert', methods=["POST"])
def insert():
    tbl='COMPANY_DOCUMENT_LIST'
    (document_num, comp_id, category, document_name, company_deploy, from_save_date, disposal_date, remark)=\
        request.form["document_num"], request.form["comp_id"], request.form["category"], request.form["document_name"],\
        request.form["company_deploy"], request.form["from_save_date"], request.form["disposal_date"], request.form["remark"]
    sql=f'INSERT INTO {tbl} VALUES (?,?,?,?,?,?,?,?);'
    conn=sqlite3.connect(db_name)
    cursor=conn.cursor()
    cursor.execute(sql)
    conn.commit()
    conn.close()
    return 'INSERT'

@app.route('/update', methods=["POST"])
def update():
    return 'UPDATE'

@app.route('/delete', methods=["POST"])
def delete():
    return 'BODY'

if __name__=='__main__':
    app.run(port=port, debug=debug)
